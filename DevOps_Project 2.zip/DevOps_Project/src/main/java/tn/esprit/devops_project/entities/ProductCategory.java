package tn.esprit.devops_project.entities;

public enum ProductCategory {
    ELECTRONICS, CLOTHING, BOOKS
}
